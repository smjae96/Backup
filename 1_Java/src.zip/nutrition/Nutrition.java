package nutrition;

public interface Nutrition {

	public static int GRAMCARB = 4;
	public static int GRAMPROTEIN = 4;
	public static int GRAMFAT = 9;
}
