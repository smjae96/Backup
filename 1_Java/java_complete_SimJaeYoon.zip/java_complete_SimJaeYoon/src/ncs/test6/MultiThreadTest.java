package ncs.test6;

public class MultiThreadTest {

	public static void main(String[] args) {

	}

}
