package food;

public class HomeCook extends Food {

	public HomeCook(String name, double carb, double protein, double fat) {
		super(name, carb, protein, fat);
	}

}
