package com.kh.interface_practice;

public interface TestIf1 {

}
