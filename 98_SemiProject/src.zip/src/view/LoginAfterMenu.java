package view;

public class LoginAfterMenu {

	public static void mainMenu(String userId) {
		System.out.println("로그인 성공!");
	}
}
