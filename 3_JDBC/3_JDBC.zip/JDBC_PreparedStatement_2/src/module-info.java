module JDBC_Statement_01 {
	requires java.sql;
}