package com.kh.practice.chap02_abstractNInterface.model.vo;

public interface NotePen {
	// ���
	public static final boolean PEN_BUTTON = true;
	
	boolean bluetoothPen();
}
