package food;

public class Burgerking extends Food {

	public Burgerking(String name, double carb, double protein, double fat) {
		super(name, carb, protein, fat);
	}

}
