package com.kh.run;

import com.kh.controller.PlayController;
import com.kh.view.DisplayMenu;

public class Run {
	public static void main(String[] args) {
		DisplayMenu dm = new DisplayMenu();
		//pc.method01();
		//pc.method02();
//		pc.method03();
//		pc.getUserInfo();
		dm.mainMenu();
	}
}
