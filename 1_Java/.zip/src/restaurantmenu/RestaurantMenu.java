package restaurantmenu;

import java.util.ArrayList;

public class RestaurantMenu {
    private ArrayList<Food> menu;

    public RestaurantMenu(ArrayList<Food> menu) {
        this.menu = menu;
    }

    // Getter and Setter methods
}

