package run;

import view.LoginMenu;

public class Run {
	
	public static void main(String[] args) {
		LoginMenu lm = new LoginMenu();
		
		lm.mainMenu();
	}
}
