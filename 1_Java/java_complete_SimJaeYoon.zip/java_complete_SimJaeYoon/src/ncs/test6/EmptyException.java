package ncs.test6;

public class EmptyException {

	public EmptyException(String message) {
		super()
	}
}
