package food;

public class Hansot extends Food {

	public Hansot(String name, double carb, double protein, double fat) {
		super(name, carb, protein, fat);
	}

}
