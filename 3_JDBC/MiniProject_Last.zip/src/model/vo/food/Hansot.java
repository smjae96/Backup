package model.vo.food;

public class Hansot extends Food {
	
	public Hansot(String name, double carb, double protein, double fat, int price) {
		super(name, carb, protein, fat, price);
		
	}

	

}
