package com.kh.practice.generics.run;

import com.kh.practice.generics.view.FarmMenu;

public class Run {

	public static void main(String[] args) {
		FarmMenu fm = new FarmMenu();
		fm.mainMenu();
		//fm.printFarm();
	}

}
