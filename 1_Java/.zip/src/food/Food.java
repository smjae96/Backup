package food;

public class Food {
    private String name;
    private int carbohydrate;
    private int protein;
    private int fat;

    public Food(String name, int carbohydrate, int protein, int fat) {
        this.name = name;
        this.carbohydrate = carbohydrate;
        this.protein = protein;
        this.fat = fat;
    }

    // Getter and Setter methods
}

