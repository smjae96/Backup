package dto;

import java.sql.Connection;
import java.sql.Statement;

import food.Burgerking;

public class DTO {

	public static void main(String[] args) {
		int result = 0;
		Connection conn = null;
		Statement stmt = null;
		MenuCreator
		
		String sql = "INSERT INTO BURGERKING VALUES ("+
	}
}
