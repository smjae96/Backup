package com.kh.hospital_reception.run;

import com.kh.hospital_reception.menu.BookMenu;

public class Run {

	public static void main(String[] args) {
		BookMenu bookmenu = new BookMenu();
		
		bookmenu.mainMenu();
	}

}
