package ncs.test6;

public class Data {
	private int value;
	private boolean isEmpty = true;
	
	public Data() {
		
	}
	public void setValue(int value) {
		this.value = value;
	}
	public int getValue() {
		return value;
	}
}
