package com.kh.practice.book.run;

public class Run {

	public static void main(String[] args) {

	}

}
